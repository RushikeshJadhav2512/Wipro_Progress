using Project2.Models;

namespace Project2.Interfaces
{
    public interface IReportFormatter
    {
        string Format(Report report);
    }
}