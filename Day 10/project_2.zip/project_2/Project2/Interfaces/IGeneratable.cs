namespace Project2.Interfaces
{
    public interface IGeneratable
    {
        void Generate();
    }
}