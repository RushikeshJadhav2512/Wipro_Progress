namespace Project2.Interfaces
{
    public interface IReport
    {
        string GetContent();
    }
}