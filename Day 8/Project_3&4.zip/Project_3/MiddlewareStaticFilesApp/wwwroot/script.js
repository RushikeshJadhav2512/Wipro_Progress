function show() {
    alert("Static JS Loaded Successfully");
}