using System.Collections.Generic;

namespace LibraryManagementSystem.Core.Models
{
    public class Borrower
    {
        public int BorrowerId { get; set; }
        public string Name { get; set; }
    }
}