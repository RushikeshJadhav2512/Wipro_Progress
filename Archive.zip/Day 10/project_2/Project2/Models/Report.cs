namespace Project2.Models
{
    public class Report
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}