namespace Project2.Interfaces
{
    public interface ISavable
    {
        void Save();
    }
}